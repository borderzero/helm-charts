#!/usr/bin/env bash
#
# verify_cluster_and_rollout.sh — verify the tailzero-connector state-persistence fix
# on a kind cluster: rollout-restart the connector and confirm it keeps the same
# Tailscale node key across the restart (a changed key would mean a new machine).
#
# Usage:   ./verify_cluster_and_rollout.sh -i <INVITE_CODE>
# Options: -i invite code (or $INVITE_CODE)  -c cluster(tz)  -n ns(border0)
#          -r release(tailzero-connector)  -t timeout(180)
#
set -euo pipefail

CLUSTER=tz
NS=border0
REL=tailzero-connector
TIMEOUT=180
INVITE_CODE="${INVITE_CODE:-}"
# chart root (this script lives in <chart>/docs/)
CHART="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

while getopts "i:c:n:r:t:h" opt; do
  case "$opt" in
    i) INVITE_CODE="$OPTARG" ;;
    c) CLUSTER="$OPTARG" ;;
    n) NS="$OPTARG" ;;
    r) REL="$OPTARG" ;;
    t) TIMEOUT="$OPTARG" ;;
    h) awk 'NR==1{next} /^#/{sub(/^# ?/,"");print;next} {exit}' "$0"; exit 0 ;;
    *) echo "see -h for usage" >&2; exit 2 ;;
  esac
done

c_blue=$'\033[1;34m'; c_green=$'\033[1;32m'; c_red=$'\033[1;31m'; c_off=$'\033[0m'
say(){ printf '%s==>%s %s\n' "$c_blue"  "$c_off" "$*"; }
ok(){  printf '%s OK %s %s\n' "$c_green" "$c_off" "$*"; }
die(){ printf '%sERR%s %s\n' "$c_red"   "$c_off" "$*" >&2; exit 1; }

[ -n "$INVITE_CODE" ] || die "invite code required: pass -i <code> or set INVITE_CODE"
for t in kubectl helm; do command -v "$t" >/dev/null || die "missing required tool: $t"; done

# ensure a reachable cluster
say "verifying cluster"
if kubectl cluster-info >/dev/null 2>&1 && [ "$(kubectl config current-context 2>/dev/null)" = "kind-$CLUSTER" ]; then
  ok "using current context kind-$CLUSTER"
elif command -v kind >/dev/null && kind get clusters 2>/dev/null | grep -qx "$CLUSTER"; then
  kubectl config use-context "kind-$CLUSTER" >/dev/null; ok "switched to context kind-$CLUSTER"
elif command -v kind >/dev/null; then
  say "creating kind cluster '$CLUSTER'"; kind create cluster --name "$CLUSTER"
else
  kubectl cluster-info >/dev/null 2>&1 || die "no reachable cluster and kind is not installed"
  ok "using current kubectl context: $(kubectl config current-context)"
fi

# read the connector's node key from logs (polls until present)
read_node_key() {
  local deadline=$((SECONDS + TIMEOUT)) k=""
  while [ "$SECONDS" -lt "$deadline" ]; do
    k="$(kubectl -n "$NS" logs -l "app.kubernetes.io/instance=$REL" --tail=-1 2>/dev/null \
         | sed -n 's/.*got node key: //p' | head -1)"
    [ -n "$k" ] && { printf '%s' "$k"; return 0; }
    sleep 3
  done
  return 1
}

say "helm upgrade --install"
helm upgrade --install "$REL" "$CHART" -n "$NS" --create-namespace \
  --set config.inviteCode="$INVITE_CODE" >/dev/null
kubectl -n "$NS" rollout status "deploy/$REL" --timeout="${TIMEOUT}s"

say "reading node key before restart"
BEFORE="$(read_node_key)" || die "connector never logged 'got node key:' (check creds: kubectl -n $NS logs -l app.kubernetes.io/instance=$REL)"
ok "before: $BEFORE"

say "kubectl rollout restart deploy/$REL"
kubectl -n "$NS" rollout restart "deploy/$REL" >/dev/null
kubectl -n "$NS" rollout status  "deploy/$REL" --timeout="${TIMEOUT}s"

say "reading node key after restart"
AFTER="$(read_node_key)" || die "connector never logged 'got node key:' after restart"
ok "after:  $AFTER"

echo
if [ "$BEFORE" = "$AFTER" ]; then
  ok "FIX VERIFIED: node key unchanged -> SAME Tailscale machine reconnected"
else
  die "node key changed ($BEFORE -> $AFTER) -> new machine (is the PVC bound? kubectl -n $NS get pvc)"
fi
